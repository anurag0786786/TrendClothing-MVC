﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;
using TrendClothing.DataAccess.Repository.IRepository;
using TrendClothing.Models;

namespace TrendClothing.Areas.Customer.Controllers
{
    [Area("Customer")]
    [Authorize]
    public class WishlistController : Controller
    {
        private readonly IUnitofWork _unitOfWork;

        public WishlistController(IUnitofWork unitOfWork)
        {
            _unitOfWork = unitOfWork;
        }

        // VIEW WISHLIST
        public IActionResult Index()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var items = _unitOfWork.Wishlist.GetAll(
                w => w.ApplicationUserId == userId,
                IncludeProperties: "Product,Product.Brand,Product.Category"
            );
            return View(items);
        }

        // TOGGLE (Add / Remove)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Toggle(int productId, string? returnUrl = null)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var existing = _unitOfWork.Wishlist.FirstOrDefault(
                w => w.ApplicationUserId == userId && w.ProductId == productId);

            if (existing != null)
            {
                _unitOfWork.Wishlist.Remove(existing);
                TempData["ToastMessage"] = "Wishlist se remove ho gaya";
                TempData["ToastColor"] = "gray";
            }
            else
            {
                var product = _unitOfWork.product.Get(productId);
                if (product == null) return NotFound();

                _unitOfWork.Wishlist.Add(new Wishlist
                {
                    ApplicationUserId = userId,
                    ProductId = productId,
                    AddedOn = DateTime.UtcNow
                });
                TempData["ToastMessage"] = "Wishlist mein add ho gaya";
                TempData["ToastColor"] = "#c1440e";
            }

            _unitOfWork.Save();

            // FIX: returnUrl valid hai to wahan jao, warna Detail page pe wapas
            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                return Redirect(returnUrl);

            // returnUrl nahi aaya to Detail page pe bhejo
            return RedirectToAction("Details", "Home", new { area = "Customer", id = productId });
        }

        // CHECK (heart icon ke liye)
        [HttpGet]
        public IActionResult IsWishlisted(int productId)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var exists = _unitOfWork.Wishlist.FirstOrDefault(
                w => w.ApplicationUserId == userId && w.ProductId == productId) != null;
            return Json(new { wishlisted = exists });
        }

        // GET COUNT
        [HttpGet]
        public IActionResult GetCount()
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            var count = _unitOfWork.Wishlist.GetAll(w => w.ApplicationUserId == userId).Count();
            return Json(new { count });
        }
    }
}